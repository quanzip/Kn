<h1>Sử dụng Redisson với Java</h1>

<h2>1. Dependency</h2>
   #### 1.1 Sử dụng maven
   Thêm đoạn sau trong pom.xml
        
        <dependency>
             <groupId>org.redisson</groupId>
             <artifactId>redisson</artifactId>
             <version>3.16.5</version>
         </dependency>
   #### 1.2 Sử dụng gradle
        compile 'org.redisson:redisson:3.16.5'
<h2>2. Kết nối Redisson với Redis</h2>
   #### 2.1 Các kết nối Redisson hỗ trợ
   - Single node: Thông số cấu hình tham khảo tại <a href="https://github.com/redisson/redisson/wiki/2.-Configuration#261-single-instance-settings">đây</a>
   - Master with slaves nodes: Thông số cấu hình tham khảo tại <a href="https://github.com/redisson/redisson/wiki/2.-Configuration#281-master-slave-settings">đây</a>
   - Sentinel nodes: Thông số cấu hình tham khảo tại <a href="https://github.com/redisson/redisson/wiki/2.-Configuration#271-sentinel-settings">đây</a>
   - Clustered nodes: Thông số cấu hình tham khảo tại <a href="https://github.com/redisson/redisson/wiki/2.-Configuration#241-cluster-settings">đây</a>
   - Replicated nodes: Thông số cấu hình tham khảo tại <a href="https://github.com/redisson/redisson/wiki/2.-Configuration#251-replicated-settings">đây</a>
   #### 2.2 Cấu hình trực tiếp trong Java
   Chúng ta có thể cấu hình để tạo kết nối đến Redis trực tiếp trong Java như sau:

       Config config = new Config();
       config.useSingleServer()
         .setAddress("127.0.0.1:6379");
       RedissonClient client = Redisson.create(config);
   
   #### 2.3 Cấu hình thông qua file
   Redisson hỗ trợ load cấu hình từ file định dạng JSON hoặc YAML
   
       Config config = Config.fromJSON(new File("singleNodeConfig.json"));  
       // ... tương tự với fromYAML
       RedissonClient client = Redisson.create(config);
       
   Đây là mẫu config cho singleNodeConfig.json
   
       {
           "singleServerConfig": {
               "idleConnectionTimeout": 10000,
               "pingTimeout": 1000,
               "connectTimeout": 10000,
               "timeout": 3000,
               "retryAttempts": 3,
               "retryInterval": 1500,
               "reconnectionTimeout": 3000,
               "failedAttempts": 3,
               "password": null,
               "subscriptionsPerConnection": 5,
               "clientName": null,
               "address": "redis://127.0.0.1:6379",
               "subscriptionConnectionMinimumIdleSize": 1,
               "subscriptionConnectionPoolSize": 50,
               "connectionMinimumIdleSize": 10,
               "connectionPoolSize": 64,
               "database": 0,
               "dnsMonitoring": false,
               "dnsMonitoringInterval": 5000
           },
           "threads": 0,
           "nettyThreads": 0,
           "codec": null,
           "useLinuxNativeEpoll": false
       }
       
   Đây là mẫu config cho singleNodeConfig.yaml
   
       singleServerConfig:
           idleConnectionTimeout: 10000
           pingTimeout: 1000
           connectTimeout: 10000
           timeout: 3000
           retryAttempts: 3
           retryInterval: 1500
           reconnectionTimeout: 3000
           failedAttempts: 3
           password: null
           subscriptionsPerConnection: 5
           clientName: null
           address: "redis://127.0.0.1:6379"
           subscriptionConnectionMinimumIdleSize: 1
           subscriptionConnectionPoolSize: 50
           connectionMinimumIdleSize: 10
           connectionPoolSize: 64
           database: 0
           dnsMonitoring: false
           dnsMonitoringInterval: 5000
       threads: 0
       nettyThreads: 0
       codec: !<org.redisson.codec.JsonJacksonCodec> {}
       useLinuxNativeEpoll: false
   
   Để lưu từ cấu hình Java sang file JSON hoặc YAML config, chúng ta thực hiện như sau:
   
       Config config = new Config();
       // ... we configure multiple settings here in Java
       String jsonFormat = config.toJSON();
       String yamlFormat = config.toYAML();
<h2>3. Thao tác với Redis</h2>
   #### 3.1 Một số kiểu dữ liệu
   - Map
   - MultiMap
   - Set
   - SortedSet
   - ScoredSortedSet
   - LexSortedSet
   - List
   - Queue
   - Deque
   - BlockingQueue
   - BoundBlockingQueue
   - BlockingDeque
   - BlockingFairQueue
   - DelayedQueue
   - PriorityQueue
   - PriorityDeque
   
   Chi tiết đầy đủ về cách sử dụng Collections trong Redisson, hãy xem tham khảo tại <a href="https://github.com/redisson/redisson/wiki/7.-distributed-collections">đây</a>
   
   #### 3.2 Khóa và đồng bộ
   Trong Redisson, các khóa và bộ đồng bộ hóa được phân phối, cho phép bạn đồng bộ hóa các luồng trên nhiều ứng dụng và máy chủ. Các khóa và bộ đồng bộ hóa Java được Redisson hỗ trợ là:
   
   - Lock
   - FairLock
   - MultiLock
   - ReadWriteLock
   - Semaphore
   - PermitExpirableSemaphore
   - CountDownLatch
   
   ##### Lock
   Các luồng có thể khóa một tài nguyên nhiều hơn một lần. Một biến bộ đếm theo dõi số lần yêu cầu khóa đã được thực hiện. Tài nguyên được giải phóng sau khi luồng thực hiện đủ yêu cầu mở khóa và bộ đếm đạt đến 0.
   
       RLock lock = redisson.getLock("anyLock");
       lock.lock();
       try {
         ...
       } finally {
         lock.unlock();
       }
   
   Nếu một instance Redisson đang khóa mà bị treo hoặc crash, thì có thể khóa sẽ bị treo vĩnh viễn ở trạng thái khóa. Để tránh điều này, Redisson duy trì một "cơ chế giám sát" khóa để kéo dài thời gian hết hạn của khóa trong khi instance Redisson giữ khóa vẫn còn sống. Theo mặc định, thời gian chờ cho cơ chế giám sát khóa này là 30 giây. Giới hạn này có thể được thay đổi bằng lệnh Config.lockWatchdogTimeout.
   Redisson cũng cho phép bạn chỉ định leaseTime tham số khi bắt đầu thực hiện khóa. Sau khoảng thời gian được chỉ định, khóa sẽ tự động được mở.
   ***Lưu ý chỉ có luồng thực hiện khóa mới có thể mở khóa***
   
       RLock lock = redisson.getLock("myLock");
       
       // traditional lock method
       lock.lock();
       
       // or acquire lock and automatically unlock it after 10 seconds
       lock.lock(10, TimeUnit.SECONDS);
       
       // or wait for lock aquisition up to 100 seconds 
       // and automatically unlock it after 10 seconds
       boolean res = lock.tryLock(100, 10, TimeUnit.SECONDS);
       if (res) {
          try {
            ...
          } finally {
              lock.unlock();
          }
       }
   
   ##### FairLock
   Bằng cách sử dụng FairLock, bạn có thể đảm bảo rằng các luồng sẽ nhận được tài nguyên theo đúng thứ tự mà họ đã yêu cầu (tức là hàng đợi "nhập trước, xuất trước"). Redisson cung cấp cho các luồng đã chết năm giây để khởi động lại trước khi tài nguyên được mở khóa cho luồng tiếp theo trong hàng đợi.
   
       RLock lock = redisson.getFairLock("myLock");
       
       // traditional lock method
       lock.lock();
       
       // or acquire lock and automatically unlock it after 10 seconds
       lock.lock(10, TimeUnit.SECONDS);
       
       // or wait for lock aquisition up to 100 seconds 
       // and automatically unlock it after 10 seconds
       boolean res = lock.tryLock(100, 10, TimeUnit.SECONDS);
       if (res) {
          try {
            ...
          } finally {
              lock.unlock();
          }
       }
          
   ##### MultiLock
   Redis dựa và đối tượng RMultiLock để cho phép gom nhóm các đối tượng RLock và xử lý chúng như một khóa đơn lẻ. Mỗi một RLock có thể thuộc về các Redisson instance khác nhau.
   
       RLock lock1 = redisson1.getLock("lock1");
       RLock lock2 = redisson2.getLock("lock2");
       RLock lock3 = redisson3.getLock("lock3");
       
       RLock multiLock = anyRedisson.getMultiLock(lock1, lock2, lock3);
       
       // traditional lock method
       multiLock.lock();
       
       // or acquire lock and automatically unlock it after 10 seconds
       multiLock.lock(10, TimeUnit.SECONDS);
       
       // or wait for lock aquisition up to 100 seconds 
       // and automatically unlock it after 10 seconds
       boolean res = multiLock.tryLock(100, 10, TimeUnit.SECONDS);
       if (res) {
          try {
            ...
          } finally {
              multiLock.unlock();
          }
       }
   ##### ReadWriteLock
   Một ReadWriteLock duy trì một cặp khóa, một khóa dành cho các hoạt động chỉ đọc và một khóa để ghi. Khóa đọc có thể được giữ đồng thời bởi nhiều luồng đọc, miễn là không có viết. Khóa ghi chỉ có một luồng được sử dụng.
   
   Khi một luồng sử dụng khóa đọc, nó sẽ thấy các cập nhật ngay trước khi khóa ghi được release.
   
   Nó khai thác thực tế là mặc dù chỉ một luồng duy nhất tại một thời điểm (luồng ghi) có thể sửa đổi dữ liệu được chia sẻ, trong nhiều trường hợp, bất kỳ số lượng luồng nào cũng có thể đồng thời đọc dữ liệu (luồng đọc).
    
       RReadWriteLock rwlock = redisson.getReadWriteLock("myLock");
       
       RLock lock = rwlock.readLock();
       // or
       RLock lock = rwlock.writeLock();
       
       // traditional lock method
       lock.lock();
       
       // or acquire lock and automatically unlock it after 10 seconds
       lock.lock(10, TimeUnit.SECONDS);
       
       // or wait for lock aquisition up to 100 seconds 
       // and automatically unlock it after 10 seconds
       boolean res = lock.tryLock(100, 10, TimeUnit.SECONDS);
       if (res) {
          try {
            ...
          } finally {
              lock.unlock();
          }
       }
   Tham khảo thêm về khóa tại <a href="https://github.com/redisson/redisson/wiki/8.-distributed-locks-and-synchronizers">đây</a>
<h2>4. Ví dụ</h2>
    Ta có đoạn code đang sử dụng Jedis sau đây:

       public static final String PREFIX_ENQUEUE = "ENQUEUE_ACD";
      
       public List<RedisObject> findAllRedisObject() {
           List<RedisObject> listRs = new ArrayList<>();
           try {
               JedisCluster jedis = getRedis();
               Map<byte[], byte[]> mapData = jedis.hgetAll(PREFIX_ENQUEUE.getBytes());
               if (mapData != null && !mapData.isEmpty()) {
                   for (Map.Entry<byte[], byte[]> pair : mapData.entrySet()) {
                       logger.info(new String(pair.getKey()));
                       RedisObject object = (RedisObject) Utils.deserializeObj(pair.getValue());
                       listRs.add(object);
                   }
               }
           } catch (Exception e) {
               logger.error(e.getMessage(), e);
           }
           return listRs;
       }
    
   Ta sẽ chuyển về sử dụng Redisson kết hợp với lock:
   
       public static final String PREFIX_ENQUEUE = "ENQUEUE_ACD";
       public static final String LOCK_NAME = "LOCK";
         
       public List<RedisObject> findAllRedisObject() {
           List<RedisObject> listRs = new ArrayList<>();
           RedissonClient client = getRedisClient();
           RLock lock = client.getLock(LOCK_NAME);
           lock.lock();
           try {
               RMap<byte[], byte[]> mapData = client.getMap(PREFIX_ENQUEUE);
               if (mapData != null && !mapData.isEmpty()) {
                   for (Map.Entry<byte[], byte[]> pair : mapData.entrySet()) {
                       logger.info(new String(pair.getKey()));
                       RedisObject object = (RedisObject) Utils.deserializeObj(pair.getValue());
                       listRs.add(object);
                   }
               }
           } finnally {
               lock.unlock();
               logger.info(LOCK_NAME + " is unlocked");
           }
           return listRs;
       }
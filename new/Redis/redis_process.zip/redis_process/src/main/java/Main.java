import client.Client;
import org.awaitility.Awaitility;
import org.awaitility.Duration;
import org.redisson.api.*;
import process.RunnableDemo;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;


public class Main {
    public static void main(String[] args) throws InterruptedException {
        testSingleInstance("lock", "myMap");
    }

    static void testSingleInstance(String lockName, String mapName) throws InterruptedException {
        RunnableDemo runnableDemo = new RunnableDemo("Thread Single",100, mapName);
        runnableDemo.start();
        Thread.sleep(2000);
        RedissonClient redissonClient = Client.getInstance().getClient();
        redissonClient.getMap("myMap").put(0,"New Item");
        System.out.println("New value 1:" + redissonClient.getMap("myMap").get(0));
        RLock lock = redissonClient.getLock("lock");
        lock.lock();
        System.out.println(lock.isLocked());
        System.out.println("New value 2:" + redissonClient.getMap("myMap").get(0));
        lock.unlock();
    }

    static void testMultiInstance(String lockName, String mapName) throws InterruptedException {
        RunnableDemo runnableDemo = new RunnableDemo("Thread Single",100, mapName);
        runnableDemo.start();
        Thread.sleep(2000);
        RedissonClient redissonClient = Client.getInstance().getOtherClient();
        redissonClient.getMap("myMap").put(0,"New Item");
        System.out.println("New value 1:" + redissonClient.getMap("myMap").get(0));
        RLock lock = redissonClient.getLock("lock");
        lock.lock();
        System.out.println(lock.isLocked());
        System.out.println("New value 2:" + redissonClient.getMap("myMap").get(0));
        lock.unlock();
    }

    static void testReadWrite() throws InterruptedException {
        RedissonClient redisson = Client.getInstance().getClient();

        final RReadWriteLock lock = redisson.getReadWriteLock("lock");

        lock.writeLock().tryLock();

        Thread t = new Thread(() -> {
            RLock r = lock.readLock();
            r.lock();

            try {
                Thread.sleep(1000);
                System.out.println(redisson.getMap("myMap").get(1));

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            r.unlock();
        });

        t.start();
        t.join();

        lock.writeLock().unlock();

        t.join();

        redisson.shutdown();
    }

    public static void testWriteReadReentrancy() throws InterruptedException {
        RedissonClient redisson = Client.getInstance().getClient();
        RReadWriteLock readWriteLock = redisson.getReadWriteLock("TEST");
        readWriteLock.writeLock().lock();
        java.util.concurrent.locks.Lock rLock = readWriteLock.readLock();
        System.out.println("Try lock is true? " + rLock.tryLock());
        AtomicBoolean ref = new AtomicBoolean();
        Thread t1 = new Thread(() -> {
            boolean success = readWriteLock.readLock().tryLock();
            ref.set(success);
        });
        t1.start();
        t1.join();
        System.out.println("Ref is false? " + ref.get());
        readWriteLock.writeLock().unlock();
        System.out.println("readWriteLock.writeLock().tryLock() is false? " + readWriteLock.writeLock().tryLock());
        rLock.unlock();
        System.out.println("readWriteLock.writeLock().tryLock() is true? " + readWriteLock.writeLock().tryLock());
        readWriteLock.writeLock().unlock();
    }

    public static void testExpireRead() throws InterruptedException {
        RedissonClient redisson = Client.getInstance().getClient();
        RReadWriteLock lock = redisson.getReadWriteLock("lock");
        lock.readLock().lock(2, TimeUnit.SECONDS);
        final long startTime = System.currentTimeMillis();
        Thread t = new Thread(() -> {
            RReadWriteLock lock1 = redisson.getReadWriteLock("lock");
            lock1.readLock().lock();
            long spendTime = System.currentTimeMillis() - startTime;
            System.out.println(spendTime);
            lock1.readLock().unlock();
        });
        t.start();
        t.join();
        lock.readLock().unlock();
    }

    public static void testWriteLockExpiration() throws InterruptedException {
        RedissonClient redisson = Client.getInstance().getClient();
        RReadWriteLock rw1 = redisson.getReadWriteLock("test2s3");
        RLock l1 = rw1.writeLock();
        System.out.println("l1.tryLock(10000, 10000, TimeUnit.MILLISECONDS) is true?" + l1.tryLock(10000, 10000, TimeUnit.MILLISECONDS));
        RLock l2 = rw1.writeLock();
        System.out.println("l2.tryLock(1000, 1000, TimeUnit.MILLISECONDS) is true?" + l2.tryLock(1000, 1000, TimeUnit.MILLISECONDS));
        Awaitility.await().atMost(Duration.TEN_SECONDS).until(() -> {
            RReadWriteLock rw2 = redisson.getReadWriteLock("test2s3");
            try {
                return !rw2.writeLock().tryLock(3000, 1000, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                e.printStackTrace();
                return false;
            }
        });
    }

    public static void testReadLockLeaseTimeoutDiffThreadsWRR() throws InterruptedException {
        long startTime = System.currentTimeMillis();
        RedissonClient redisson = Client.getInstance().getClient();
        RLock writeLock = redisson.getReadWriteLock("my_read_write_lock").writeLock();
        System.out.println("true?" + writeLock.tryLock(1, 20, TimeUnit.SECONDS));

        final AtomicInteger executed = new AtomicInteger();
        Thread t1 = new Thread(() -> {
            RLock readLock = redisson.getReadWriteLock("my_read_write_lock").readLock();
            readLock.lock();
            executed.incrementAndGet();
        });

        Thread t2 = new Thread(() -> {
            RLock readLock = redisson.getReadWriteLock("my_read_write_lock").readLock();
            readLock.lock();
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            executed.incrementAndGet();
        });

        t1.start();
        t2.start();

        Awaitility.await().atMost(11, TimeUnit.SECONDS).until(() -> executed.get() == 2);
        long endTime = System.currentTimeMillis();
        System.out.println(endTime - startTime);
    }

    static void testLockOneInstance() {
        RedissonClient redissonClient = Client.getInstance().getClient();
        putValueAndLock(redissonClient,"Single","Map",1,"Thông");
        putValue(redissonClient,"Single","Map",2,"Quân");
        RMap<Integer,String> res = redissonClient.getMap("Map");
        System.out.println(res.get(2));
    }

    static void putValue(RedissonClient client,String lockName, String mapName, Integer key, String value){
        RLock rlock = client.getLock(lockName);
        System.out.println(rlock.isLocked());
        rlock.lock();
        RMap<Integer,String> map = client.getMap(mapName);
        map.put(key,value);
        rlock.unlock();
    }

    static void putValueAndLock(RedissonClient client,String lockName, String mapName, Integer key, String value){
        RLock rlock = client.getLock(lockName);
        rlock.lock();
        RMap<Integer,String> map = client.getMap(mapName);
        map.put(key,value);
//        rlock.unlock();
    }
}

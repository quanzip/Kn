package client;

import org.redisson.Redisson;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

import java.io.File;
import java.io.IOException;

public class Client {
    private static Client instance;
    private RedissonClient client1;
    private RedissonClient client2;

    private Client() {
        Config config;
        try {
            config = Config.fromYAML(new File("config/cluster-config-thonglt4.yaml"));
            client1 = Redisson.create(config);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public RedissonClient getClient() {
        return client1;
    }

    public RedissonClient getOtherClient() {
        if (client2 == null) {
            Config config;
            try {
                config = Config.fromYAML(new File("config/cluster-config-thonglt4.yaml"));
                client2 = Redisson.create(config);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return client2;
    }

    public void setClient(RedissonClient client) {
        this.client1 = client;
    }

    public static synchronized Client getInstance() {
        if(instance == null){
            synchronized(Client.class) {
                if(instance == null){
                    instance = new Client();
                }
            }
        }
        return instance;
    }
}

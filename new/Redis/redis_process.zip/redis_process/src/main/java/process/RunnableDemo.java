package process;

import client.Client;
import org.redisson.api.RLock;
import org.redisson.api.RMap;
import org.redisson.api.RedissonClient;


public class RunnableDemo implements Runnable {
    private Thread t;
    private String threadName;
    private int interval;
    private String mapName;

    public RunnableDemo(String threadName, int interval, String mapName) {
        this.threadName = threadName;
        this.mapName = mapName;
        this.interval = interval;
        System.out.println("Creating " + threadName);
    }

    public void run() {
        System.out.println("Running " + threadName);
        try {
            for (int i = 0;i < 1;i++) {
                System.out.println("Thread: " + threadName + ", " + i*this.interval);
                RedissonClient client = Client.getInstance().getClient();
                RLock lock = client.getLock("lock");
                lock.lock();
                System.out.println(threadName + " in locking time..........");
                RMap<Integer,String> map = client.getMap(mapName);
                map.put(i+1,threadName + (i+1) + " XYZ");
                Thread.sleep(this.interval*100);
//                lock.unlock();
                if (!lock.isLocked())
                    System.out.println(threadName + " is unlocked.");
            }
        } catch (InterruptedException e) {
            System.out.println("Thread " + threadName + " interrupted.");
        }
        System.out.println("Thread " + threadName + " exiting.");
    }

    public void start() {
        System.out.println("Staring " + threadName);
        if (t == null) {
            t = new Thread(this, threadName);
            t.start();
        }
    }
}
